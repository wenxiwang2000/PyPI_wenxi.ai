"""Embedding UI package for local text embedding generation."""

__all__ = [
    "build_output_zip_bytes",
    "embed_zip_bytes",
    "supported_models",
]

from .core import build_output_zip_bytes, embed_zip_bytes, supported_models

__version__ = "0.1.0"
