from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO, StringIO
import csv
import json
from pathlib import Path
import re
from typing import Iterable
import zipfile

import numpy as np
from sentence_transformers import SentenceTransformer


SUPPORTED_MODELS: list[tuple[str, str]] = [
    ("BAAI/bge-small-en-v1.5", "Lightweight English retrieval"),
    ("sentence-transformers/all-MiniLM-L6-v2", "Very easy lightweight baseline"),
    ("intfloat/e5-small-v2", "Small E5 family model"),
    ("mixedbread-ai/mxbai-embed-large-v1", "Higher quality larger model"),
    ("nomic-ai/nomic-embed-text-v1.5", "Longer-context friendly"),
]

TEXT_SUFFIXES = {".md", ".txt"}


@dataclass
class EmbeddedItem:
    item_id: str
    source_file: str
    text: str
    embedding: list[float]
    char_count: int
    word_count: int
    embedding_dim: int
    model_name: str


class EmbeddingError(RuntimeError):
    pass


def supported_models() -> list[tuple[str, str]]:
    return SUPPORTED_MODELS.copy()


def _safe_stem(filename: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", Path(filename).stem).strip("_") or "embedding_output"


def _iter_texts_from_zip_bytes(zip_bytes: bytes) -> Iterable[tuple[str, str]]:
    with zipfile.ZipFile(BytesIO(zip_bytes), "r") as zf:
        for name in sorted(zf.namelist()):
            if name.endswith("/"):
                continue
            suffix = Path(name).suffix.lower()
            if suffix not in TEXT_SUFFIXES:
                continue
            text = zf.read(name).decode("utf-8", errors="ignore").strip()
            if text:
                yield name, text


def _word_count(text: str) -> int:
    return len(text.split())


def _apply_prefix(texts: list[str], prefix: str) -> list[str]:
    prefix = prefix.strip()
    if not prefix:
        return texts
    return [f"{prefix} {text}" for text in texts]


def embed_zip_bytes(
    zip_bytes: bytes,
    model_name: str,
    normalize_embeddings: bool = True,
    batch_size: int = 16,
    text_prefix: str = "",
) -> tuple[list[dict], list[EmbeddedItem], dict]:
    docs = list(_iter_texts_from_zip_bytes(zip_bytes))
    if not docs:
        raise EmbeddingError("No .md or .txt files were found inside the uploaded zip file.")

    source_files = [name for name, _ in docs]
    raw_texts = [text for _, text in docs]
    model_inputs = _apply_prefix(raw_texts, text_prefix)

    model = SentenceTransformer(model_name)
    vectors = model.encode(
        model_inputs,
        normalize_embeddings=normalize_embeddings,
        batch_size=batch_size,
        show_progress_bar=False,
    )

    items: list[EmbeddedItem] = []
    manifest: list[dict] = []

    for idx, (source_file, text, vector) in enumerate(zip(source_files, raw_texts, vectors), start=1):
        embedding = np.asarray(vector, dtype=np.float32).tolist()
        item = EmbeddedItem(
            item_id=f"emb_{idx:03d}",
            source_file=source_file,
            text=text,
            embedding=embedding,
            char_count=len(text),
            word_count=_word_count(text),
            embedding_dim=len(embedding),
            model_name=model_name,
        )
        items.append(item)
        manifest.append(
            {
                "id": item.item_id,
                "source_file": item.source_file,
                "char_count": item.char_count,
                "word_count": item.word_count,
                "embedding_dim": item.embedding_dim,
                "model_name": item.model_name,
            }
        )

    summary = {
        "input_text_files": len(items),
        "total_characters": sum(item.char_count for item in items),
        "total_words": sum(item.word_count for item in items),
        "embedding_dim": items[0].embedding_dim if items else 0,
        "model_name": model_name,
        "normalize_embeddings": bool(normalize_embeddings),
        "batch_size": int(batch_size),
        "text_prefix": text_prefix,
    }
    return manifest, items, summary


def _manifest_csv_bytes(manifest: list[dict]) -> bytes:
    out = StringIO()
    writer = csv.DictWriter(
        out,
        fieldnames=["id", "source_file", "char_count", "word_count", "embedding_dim", "model_name"],
    )
    writer.writeheader()
    writer.writerows(manifest)
    return out.getvalue().encode("utf-8")


def _embeddings_jsonl_bytes(items: list[EmbeddedItem]) -> bytes:
    lines = []
    for item in items:
        lines.append(
            json.dumps(
                {
                    "id": item.item_id,
                    "source_file": item.source_file,
                    "text": item.text,
                    "char_count": item.char_count,
                    "word_count": item.word_count,
                    "embedding_dim": item.embedding_dim,
                    "model_name": item.model_name,
                    "embedding": item.embedding,
                },
                ensure_ascii=False,
            )
        )
    return ("\n".join(lines) + "\n").encode("utf-8")


def _embeddings_csv_bytes(items: list[EmbeddedItem]) -> bytes:
    out = StringIO()
    writer = csv.writer(out)
    writer.writerow(["id", "source_file", "char_count", "word_count", "embedding_dim", "model_name", "text", "embedding_json"])
    for item in items:
        writer.writerow(
            [
                item.item_id,
                item.source_file,
                item.char_count,
                item.word_count,
                item.embedding_dim,
                item.model_name,
                item.text,
                json.dumps(item.embedding, ensure_ascii=False),
            ]
        )
    return out.getvalue().encode("utf-8")


def _embeddings_npz_bytes(items: list[EmbeddedItem]) -> bytes:
    ids = np.array([item.item_id for item in items], dtype=object)
    source_files = np.array([item.source_file for item in items], dtype=object)
    texts = np.array([item.text for item in items], dtype=object)
    embeddings = np.array([item.embedding for item in items], dtype=np.float32)
    buffer = BytesIO()
    np.savez_compressed(buffer, ids=ids, source_files=source_files, texts=texts, embeddings=embeddings)
    return buffer.getvalue()


def _summary_json_bytes(summary: dict) -> bytes:
    return json.dumps(summary, indent=2, ensure_ascii=False).encode("utf-8")


def build_output_zip_bytes(
    manifest: list[dict],
    items: list[EmbeddedItem],
    summary: dict,
    input_zip_name: str,
    formats: list[str] | tuple[str, ...],
) -> bytes:
    selected = set(formats)
    base_name = _safe_stem(input_zip_name)

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("embedding_summary.json", _summary_json_bytes(summary))
        zf.writestr("embedding_manifest.csv", _manifest_csv_bytes(manifest))
        if "jsonl" in selected:
            zf.writestr(f"{base_name}_embeddings.jsonl", _embeddings_jsonl_bytes(items))
        if "csv" in selected:
            zf.writestr(f"{base_name}_embeddings.csv", _embeddings_csv_bytes(items))
        if "npz" in selected:
            zf.writestr(f"{base_name}_embeddings.npz", _embeddings_npz_bytes(items))
    return buffer.getvalue()
