# embedding

A local UI package for turning a zip of `.md` or `.txt` chunks into embedding vectors.

## What it does

- launches with the `embedding` command
- lets you choose an embedding model from a dropdown or type a custom model name
- reads a zip of `.md` or `.txt` files
- creates one embedding vector per file
- exports a zip with:
  - `embedding_summary.json`
  - `embedding_manifest.csv`
  - `*_embeddings.jsonl` (optional)
  - `*_embeddings.csv` (optional)
  - `*_embeddings.npz` (optional)

## Install

```bash
pip install embedding
```

## Run

```bash
embedding
```

## Suggested input

Use a zip produced after your chunking step, such as the recursive chunk zip that contains many small `.md` chunk files.

## Suggested output use

- `jsonl` for readable records and pipelines
- `csv` for spreadsheet-style inspection
- `npz` for loading embeddings directly into NumPy / Python

## Notes

- This package creates embeddings from local text files using `sentence-transformers` models.
- It does not call an LLM by itself.
- It stores one vector per input chunk file.

## Ownership note

The package metadata and copyright notice are set to Wenxi Wang. You should still verify PyPI package-name availability, trademark questions, and any legal or patent issues yourself before publishing.
